Changelog More edit
===================

##version 1.1.0 - 16/07/2013

* Updated to work fine with Osclass 3.2
* Minor bug fixes
* Added dao model

##version 1.0.4 - 17/05/2013

* Security patch

##version 1.0.2 - 14/09/2011

* Added new languages: german, latvian, persian, russian, swedish

##version 1.0.1 - 26/07/2011

* Added language folder

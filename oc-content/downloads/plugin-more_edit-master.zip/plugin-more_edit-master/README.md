More edit plugin
================

Add a few more options to moderation control (moderate all, moderate edits, stablish maximum ads per week/month,...)

If you need more information, you can visit [our forums](http://forums.osclass.org/)

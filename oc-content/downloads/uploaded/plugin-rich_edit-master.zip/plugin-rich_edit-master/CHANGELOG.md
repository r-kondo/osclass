#Rich Editor plugin

##version 1.1.2 - 09/08/2013

* Fixed frontend issue, tinymce not show

##version 1.1.1 - 24/07/2013

* Updated to work fine with Osclass 3.2

##version 1.1.0 - 17/05/2013

* Security patch

##version 1.0.9 - 22/05/2012

* added retrocompatibility with osclass old versions

##version 1.0.8 - 22/05/2012

* osclass 3.1 compatible

##version 1.0.6 - 22/05/2012

* Do not clean item description and title; fix for versions > 2.3

##version 1.0.5 - 04/10/2011

* Updated tinyMCE, version 3.4.6

##version 1.0.4 - 14/09/2011

* Added new languages: german, persian, latvian, russian

##version 1.0.3 - 10/08/2011

* Added new languages: slovak, swedish

##version 1.0.2 - 26/07/2011

* Fixed some string
* Added language folder

##version 1.0.1

* Remove media and image buttons, added one for color change

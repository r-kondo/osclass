#Rich Editor plugin

It adds a WYSIWYG (TinyMCE) editor for publishing ads, fully customizable

If you need more information, you can visit [our forums](http://forums.osclass.org/).
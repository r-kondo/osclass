Changelog Time elapsed
======================

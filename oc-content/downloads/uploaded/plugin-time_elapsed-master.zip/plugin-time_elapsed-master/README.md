Time elapsed
============

This plugin shows the times takes to render each page.
Embed youtube videos
====================

This plugin extends the item to embed youtube videos.
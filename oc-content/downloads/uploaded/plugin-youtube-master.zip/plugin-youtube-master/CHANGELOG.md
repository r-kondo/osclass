Changelog Embed youtube videos
==============================

##version 1.2 - 03/09/2013

* Fixed issues with IE10 (z-index issues)

##version 1.1 - 16/07/2013

* Updated to work fine with Osclass 3.2
* Use div (block element) to display the video
* Fixed the youtube title, using h2
* Languages: Spanish (Chile) and Spanish (Peru)

##version 1.0.1 - 26/01/2012

* Fixed a PHP Notice error when adding a new item
* Added new languages: portuguese, portuguese (BR), romanian, albanian

##version 1.0 - 23/12/2011

* Improved compatibility with version 2.3+
* Added new languages: arabic, danish, estonian, finish, croatian, japanese, latvian, macedonian, malay

##version 0.9.4 - 23/11/2011

* Added support for short urls (http://youtu.be/{VIDEO})

##version 0.9.3 - 14/09/2011

* Added new translations: german, french, lithuanian, persian, russian, thai

##version 0.9.2 - 10/08/2011

* Added new translations: czech, spanish, slovak, swedish

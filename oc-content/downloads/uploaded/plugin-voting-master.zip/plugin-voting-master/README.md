Voting
======

Show voting system at item page.
Posibility of find highest/lower voted, grouping by category if is needed.

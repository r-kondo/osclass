Changelog Voting plugin
=========================

##version 1.2.1 - 05/08/2013

* Style fixes.
* Fixed missed admin folder.
* Fixed Missing argument.

##version 1.2 - 19/07/2013

* Minor improvements
* Users cannot rate their items
* Improved tooltip when show the result rating. (All stars have the same tooltip)

##version 1.1.1 - 17/05/2013

* Security patch

##version 1.1.0 - 18/07/2012

* Updated data access object, implemented ModelVoting class
* fixed javascript bug, (issues with realestate theme)
* minor style fixes
* improved voting_item_detail_user(), now accept user id as argument

##version 1.0 - 09/11/2011

* fixed issue when delete items

##version 0.9.1 - 08/11/2011

* added function for retrieve the votes using filters. get_votes($array_filter)
* added function, for show items best voted


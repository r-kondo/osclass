Payment plugin
==============

Payment system


##IMPORTANT

Support for previous (3.1 and before) versions of Osclass will be drop soon


Changelog
=========

##version 1.2 - 03/04/2013

* Fixed some problems with Paypal
Changelog
=========

##version 3.0.1 - 11/07/2014

* Fixed bug with Blockchain payment

##version 2.2.0 - 23/08/2013

* Added CoinJar method of payment

##version 2.1.0 - 20/08/2013

* Added Braintree, Blockchain and Stripe as method of payment

##version 1.2 - 03/04/2013

* Fixed some problems with Paypal
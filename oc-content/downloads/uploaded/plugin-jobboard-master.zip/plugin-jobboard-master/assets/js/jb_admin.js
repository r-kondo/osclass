$(document).ready(function(){
    $('p.help-inline:first').text(jobboard.langs.admins_help_inline);
});
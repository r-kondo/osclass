Social bookmarks
================

This plugin adds social buttons in item detail page from the next newtorks: twitter, facebook and google+.
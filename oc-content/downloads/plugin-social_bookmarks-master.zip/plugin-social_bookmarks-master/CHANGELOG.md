Changelog Social bookmarks
==========================

##version 1.1 - 17/05/2012

* Added pinterest support

##version 1.0 - 12/07/2011

* Added twitter, facebook and google plus support

Changelog sitemap generator
===========================

##version 1.2.4 - 31/05/2013

* Small improvements in URL generation
* Updated menu on the admin panel

##version 1.2.3 - 17/05/2013

* Security patch

##version 1.2.2 - 29/06/2012

* Fix bug during the installatino of the process

##version 1.2 - 07/12/2011

* Small fix on install process bug

##version 1.1 - 18/10/2011

* New structure of the list of urls: https://github.com/osclass/osclass-plugins/issues/16
* Removed urls without ads
* Removed item and static pages urls
* Changed from cron_daily to cron_weekly

##version 1.0.5 - 10/08/2011

* Added new languages: czech, slovak, swedish

##version 1.0.4.1

* Fixed date when the item was not modified

##version 1.0.4

* Fixed some problems with symbolic links

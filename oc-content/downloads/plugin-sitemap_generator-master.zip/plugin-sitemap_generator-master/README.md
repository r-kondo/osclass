Sitemap generator
=================

Create a sitemap.xml in the root folder. Very useful for the crawlers.